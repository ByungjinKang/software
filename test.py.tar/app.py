import RPi.GPIO as GPIO
import time
import datetime
from flask import Flask, render_template, request
from threading import Thread
import mysql.connector

app = Flask(__name__)

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.setup(18, GPIO.OUT)

p = GPIO.PWM(18, 100)
Frq = [262, 294]
speed = 0.5
alarm_active = True

p.start(0)

mysql_host = 'localhost'
mysql_user = 'softwareteam'
mysql_password = 'teamteam12#'
mysql_database = 'soft'

def stop_alarm():
    global alarm_active
    alarm_active = False
    alarm_save_mysql()
    p.stop()
    GPIO.cleanup()

def comple_emer():
    sender_mysql()

def run_alarm():
    try:
        while True:
            if not alarm_active:
                break

            now = datetime.datetime.now()
            formatted_time = now.strftime("%H:%M")

            timer = ["09:00", "14:00", "21:00"]

            if formatted_time in timer:
                p.start(50) 
                for fr in Frq:
                    p.ChangeFrequency(fr)
                    time.sleep(speed)

            p.stop()
            time.sleep(1)  

    except KeyboardInterrupt:
        p.stop()
        GPIO.cleanup()

@app.route('/', methods=['GET', 'POST'])
def data():
    if request.method == 'POST':
        mg_id = request.form['mg_id']
        mb_id = request.form['mb_id']
        # 입력된 값으로 필요한 로직 수행
        alarm_save_mysql(mg_id, mb_id)
        sender_mysql(mg_id, mb_id)
        return '입력이 처리되었습니다.'
    else:
        return render_template('data.html')

@app.route('/alarm')
def index():
    return render_template('index.html')

@app.route('/alarm/stop')
def stop():
    stop_alarm()
    return '알람이 종료되었습니다.'

@app.route('/emer')
def emer():
    return render_template('emer.html')

@app.route('/emer/comple')
def comple():
    comple_emer()
    return '호출이 완료되었습니다.'

def alarm_save_mysql(mg_id, mb_id):

    cnx = mysql.connector.connect(
        host=mysql_host,
        user=mysql_user,
        password=mysql_password,
        database=mysql_database
    )
    cursor = cnx.cursor()

    cursor.execute("SELECT * FROM MEMBER WHERE MB_NUM = %s", (mb_id,))

    results = cursor.fetchall()
    for row in results:
        pass
    

    now2 = datetime.datetime.now()
    formatted_time2 = now2.strftime("%H:%M:%S")

    data = {
        'MB_NUM' : mb_id,
        'MEDICINE' : row[5],
        'TIME': formatted_time2,
    }

    insert_query = "INSERT INTO MEDICINE (MB_NUM, MEDICINE, TIME) VALUES (%(MB_NUM)s, %(MEDICINE)s, %(TIME)s)"
    cursor.execute(insert_query, data)

    cnx.commit()

    cursor.close()
    cnx.close()

def sender_mysql(mg_id, mb_id):

    cnx = mysql.connector.connect(
        host=mysql_host,
        user=mysql_user,
        password=mysql_password,
        database=mysql_database
    )
    cursor = cnx.cursor()

    cursor.execute("SELECT * FROM MEMBER WHERE MB_NUM = %s", (mb_id,))

    results = cursor.fetchall()
    for row in results:
        pass

    data = {
        'EMC_CALL' : 1,
        'MB_HOME' : row[4],
        'MEDICINE' : row[5],
        'CONSIDER' : row[6]
    }

    insert_query = "INSERT INTO EMERGENCY (EMC_CALL, MB_HOME, MEDICINE, CONSIDER) VALUES (%(EMC_CALL)s, %(MB_HOME)s, %(MEDICINE)s, %(CONSIDER)s)"
    cursor.execute(insert_query, data)

    cnx.commit()

    cursor.close()
    cnx.close()

if __name__ == '__main__':
    alarm_thread = Thread(target=run_alarm)
    alarm_thread.start()
    app.run(host='0.0.0.0', port=5000)
