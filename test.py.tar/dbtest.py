import mysql.connector


cnx = mysql.connector.connect(
    host = "localhost",
    user = "softwareteam",
    password = "teamteam12#",
    database = "soft"
)

cursor = cnx.cursor()

query = "INSERT INTO test VALUES (%s, %s)"
data = ("감기약", "1")
cursor.execute(query, data)

cnx.commit()

cursor.close()
cnx.close()